package com.Ajay.Exception;

public class UserDefineException extends Exception{
	public String toString() {
		return "this is reserve keyword";
		
	}

//	public void printStackTrace() {
//		// TODO Auto-generated method stub
//		
//	}

}
