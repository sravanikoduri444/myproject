package com.Ajay;

public interface AjayInterfaceDemo {

}
