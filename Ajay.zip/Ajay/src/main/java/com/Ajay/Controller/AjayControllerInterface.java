package com.Ajay.Controller;

public interface AjayControllerInterface {

	int createProfileController();
	void viewProfileController();

	void deleteProfileController();

	void viewAllProfileController();

	 

}
